#!/bin/bash
echo 'minute 6 seen' >> notes.md
