#!/bin/bash
echo 'minute 7 seen' >> notes.md
