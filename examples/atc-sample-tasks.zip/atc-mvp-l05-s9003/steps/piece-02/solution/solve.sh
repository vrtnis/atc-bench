#!/bin/bash
echo 'minute 2 seen' >> notes.md
