#!/bin/bash
echo 'minute 3 seen' >> notes.md
