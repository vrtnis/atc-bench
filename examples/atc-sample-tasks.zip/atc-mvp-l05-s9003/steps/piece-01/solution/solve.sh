#!/bin/bash
echo 'minute 1 seen' >> notes.md
