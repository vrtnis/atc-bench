#!/bin/bash
mkdir -p /logs/verifier
if [ -s notes.md ]; then echo 1 > /logs/verifier/reward.txt; else echo 0 > /logs/verifier/reward.txt; fi
