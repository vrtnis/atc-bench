# Metro Tower

A towered airport with two parallel runways, 27L and 27R. Aircraft land and depart to the west (heading 270).
Every aircraft is IFR. The controllers' rule book is FAA Order JO 7110.65.

## Controllers and channels

Four channels are recorded, and every transcript line is tagged with the one it was heard on:

- `[118.3]` the Metro Tower frequency. The tower (local) controller works the runways and the aircraft in the air
  near the airport.
- `[121.9]` the ground frequency. The ground controller, also in Metro Tower, works aircraft and vehicles on the
  airport. Vehicles are not shown in the tracks.
- `[119.1]` the Metro Approach frequency. Metro Approach is a separate facility. Its controller works aircraft
  farther from the airport and hands arrivals to Metro Tower.
- `[line]` the phone line that joins the ground, tower and approach controllers. Pilots cannot hear it. On the
  line the tower controller is also called "local".

A pilot hears only the frequency the aircraft is on. Each controller hears their own frequency and the line.

The transcript is what was heard, as it was said. It does not say who is speaking. Callsigns are often shortened,
numbers are said in more than one way, and some calls are stepped on and repeated.

Every aircraft on the tower and approach frequencies is separated with terminal radar, and every one is within
40 miles of the antenna. The tracks show only the aircraft these controllers are working. Other aircraft that are
not talking to them may be nearby and are not shown.

Aircraft types: a heavy aircraft says "heavy" after its callsign, and the only heavy type that flies here is the
Boeing 777 (wake category B). Every other aircraft is a Boeing 737 or Airbus A320 (category F), or an Embraer 175
or CRJ900 (category G). No aircraft is a super or a Boeing 757.

Minimum vectoring altitude: 5,000 feet over the high ground west of east -20, and 2,000 feet everywhere else.

## Layout

Positions are in nautical miles east and north of the midpoint between the two landing thresholds.

- Runway 27R: threshold at east 0, north +0.25. Runway 27L: threshold at east 0, north -0.25. Both run west from there.
- Taxiways Bravo, Charlie and Delta cross both runways at east -0.5, -0.9 and -1.3.
- An aircraft is on a runway when it is within 0.05 of that runway's centreline.
- Landing aircraft leave by a high-speed exit on the outer side of their runway at about east -0.7.
- The final approach fix for each runway is 5 miles east of its threshold.

## Aircraft tracks

`current/tracks.csv` holds one row per aircraft every 5 seconds:

- `time_s`: seconds since the start of the recording
- `callsign`: the callsign code, for example DAL1432 or N415PT
- `east_nm`, `north_nm`: position as described above
- `altitude_ft`, `groundspeed_kt`

The tracks do not give headings. Which way an aircraft is going shows in how its position changes.

Arrivals come from the east on one shared final approach course and line up with their own runway only inside
2.5 miles. Until then the tracks do not show which runway an arrival will use. Only the tower says that.

## Callsigns on the radio

The radio uses spoken names. The tracks use codes.

| Spoken | Code |
|---|---|
| Delta 1432 | DAL1432 |
| United 1432 | UAL1432 |
| American 1432 | AAL1432 |
| Southwest 1432 | SWA1432 |
| JetBlue 1432 | JBU1432 |
| SkyWest 1432 | SKW1432 |
| Alaska 1432 | ASA1432 |
| Frontier 1432 | FFT1432 |
| Spirit 1432 | NKS1432 |
| Envoy 1432 | ENY1432 |
| Endeavor 1432 | EDV1432 |
| Brickyard 1432 | RPA1432 |
| November 4 1 5 Papa Tango | N415PT |

## Transcript

`current/transcript.txt` holds one line per transmission: the time, the channel and the words.
