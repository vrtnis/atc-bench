You have been following live air traffic control around Metro airport: the tower, ground and approach
frequencies and the phone line between the three controllers.

The recording stopped at 06:29 (the freeze) and has been taken away. `notes.md` holds the notes you kept.
`facility.md` describes the airport and the callsign table.

Answer every question in `probes.json`, using only your notes.

Write your answers to `answers.json` in the working directory, as one JSON object that maps each
question id to your answer, for example:

```json
{"q01": "4000", "q02": "DAL1432", "q07": {"aircraft": "none", "required_action": "No action is required"}}
```

- If a question lists `options`, answer with exactly one of them, as a string.
- If a question lists `fields`, answer with a JSON object that has every field. These questions are graded
  against a rubric of checks drawn from the controller's rule book, and some checks must pass for any credit.
- Otherwise follow the question's `format`.
- Answer every question, even if you have to guess.
