#!/bin/bash
mkdir -p /logs/verifier
{ echo "pwd: $(pwd)"; ls -la; echo "notes bytes: $(wc -c < notes.md 2>/dev/null)"; } > /logs/verifier/diagnostics.txt 2>&1
cp notes.md /logs/verifier/final_notes.md 2>/dev/null
AUD=/var/lib/atc-audit
sort -u "$AUD/outside.txt" 2>/dev/null > /logs/verifier/outside_files.txt
python3 /tests/score.py /tests/key.json answers.json /logs/verifier /logs/verifier/outside_files.txt "$AUD/marker"
echo "--- files written outside the working directory between steps: $(wc -l < /logs/verifier/outside_files.txt)"
head -n 60 /logs/verifier/outside_files.txt
