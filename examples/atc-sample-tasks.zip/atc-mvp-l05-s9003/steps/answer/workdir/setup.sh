#!/bin/bash
# Runs before each step, after this step's files have been copied into the working directory.
# notes.md is the only thing that may carry information from one step to the next.
case "$PWD" in /|/root|/home|/tmp|/usr*|/etc*|/var*|/bin*|/lib*) exit 0;; esac   # never clean a system directory

# 1. Record files written outside the working directory since the previous step. They are reported with the score.
AUD=/var/lib/atc-audit
mkdir -p "$AUD" 2>/dev/null
if [ -f "$AUD/marker" ]; then
  find / \( -path /proc -o -path /sys -o -path /dev -o -path /run -o -path /logs -o -path /tests -o -path "$AUD" -o -path "$PWD" \) -prune \
       -o -type f -cnewer "$AUD/marker" -print 2>/dev/null | head -n 300 >> "$AUD/outside.txt"
  find /dev/shm -type f -cnewer "$AUD/marker" -print 2>/dev/null | head -n 50 >> "$AUD/outside.txt"
fi
touch "$AUD/marker" 2>/dev/null

# 2. The notes: a plain file, made afresh so nothing rides along with it, and cut to the limit.
rm -rf .notes_new
if [ -L notes.md ] || [ ! -f notes.md ]; then rm -rf notes.md; : > notes.md; fi
head -c 6000 notes.md > .notes_new 2>/dev/null
rm -rf notes.md
mv .notes_new notes.md

# 3. This step's recording: only the two delivered files, as plain files.
if [ -L current ]; then
  rm -rf .cur; mkdir .cur
  cp current/transcript.txt current/tracks.csv .cur/ 2>/dev/null
  rm -f current; mv .cur current
fi
if [ -d current ]; then
  find current -mindepth 1 -maxdepth 1 \( ! -type f -o \( ! -name transcript.txt ! -name tracks.csv \) \) -exec rm -rf {} + 2>/dev/null
fi

# 4. Files this step is given are written out again from this script, whatever was done to them.
rm -rf facility.md
cat > facility.md <<'ATC_FACILITY_EOF'
# Metro Tower

A towered airport with two parallel runways, 27L and 27R. Aircraft land and depart to the west (heading 270).
Every aircraft is IFR. The controllers' rule book is FAA Order JO 7110.65.

## Controllers and channels

Four channels are recorded, and every transcript line is tagged with the one it was heard on:

- `[118.3]` the Metro Tower frequency. The tower (local) controller works the runways and the aircraft in the air
  near the airport.
- `[121.9]` the ground frequency. The ground controller, also in Metro Tower, works aircraft and vehicles on the
  airport. Vehicles are not shown in the tracks.
- `[119.1]` the Metro Approach frequency. Metro Approach is a separate facility. Its controller works aircraft
  farther from the airport and hands arrivals to Metro Tower.
- `[line]` the phone line that joins the ground, tower and approach controllers. Pilots cannot hear it. On the
  line the tower controller is also called "local".

A pilot hears only the frequency the aircraft is on. Each controller hears their own frequency and the line.

The transcript is what was heard, as it was said. It does not say who is speaking. Callsigns are often shortened,
numbers are said in more than one way, and some calls are stepped on and repeated.

Every aircraft on the tower and approach frequencies is separated with terminal radar, and every one is within
40 miles of the antenna. The tracks show only the aircraft these controllers are working. Other aircraft that are
not talking to them may be nearby and are not shown.

Aircraft types: a heavy aircraft says "heavy" after its callsign, and the only heavy type that flies here is the
Boeing 777 (wake category B). Every other aircraft is a Boeing 737 or Airbus A320 (category F), or an Embraer 175
or CRJ900 (category G). No aircraft is a super or a Boeing 757.

Minimum vectoring altitude: 5,000 feet over the high ground west of east -20, and 2,000 feet everywhere else.

## Layout

Positions are in nautical miles east and north of the midpoint between the two landing thresholds.

- Runway 27R: threshold at east 0, north +0.25. Runway 27L: threshold at east 0, north -0.25. Both run west from there.
- Taxiways Bravo, Charlie and Delta cross both runways at east -0.5, -0.9 and -1.3.
- An aircraft is on a runway when it is within 0.05 of that runway's centreline.
- Landing aircraft leave by a high-speed exit on the outer side of their runway at about east -0.7.
- The final approach fix for each runway is 5 miles east of its threshold.

## Aircraft tracks

`current/tracks.csv` holds one row per aircraft every 5 seconds:

- `time_s`: seconds since the start of the recording
- `callsign`: the callsign code, for example DAL1432 or N415PT
- `east_nm`, `north_nm`: position as described above
- `altitude_ft`, `groundspeed_kt`

The tracks do not give headings. Which way an aircraft is going shows in how its position changes.

Arrivals come from the east on one shared final approach course and line up with their own runway only inside
2.5 miles. Until then the tracks do not show which runway an arrival will use. Only the tower says that.

## Callsigns on the radio

The radio uses spoken names. The tracks use codes.

| Spoken | Code |
|---|---|
| Delta 1432 | DAL1432 |
| United 1432 | UAL1432 |
| American 1432 | AAL1432 |
| Southwest 1432 | SWA1432 |
| JetBlue 1432 | JBU1432 |
| SkyWest 1432 | SKW1432 |
| Alaska 1432 | ASA1432 |
| Frontier 1432 | FFT1432 |
| Spirit 1432 | NKS1432 |
| Envoy 1432 | ENY1432 |
| Endeavor 1432 | EDV1432 |
| Brickyard 1432 | RPA1432 |
| November 4 1 5 Papa Tango | N415PT |

## Transcript

`current/transcript.txt` holds one line per transmission: the time, the channel and the words.
ATC_FACILITY_EOF
rm -rf probes.json
cat > probes.json <<'ATC_PROBES_EOF'
[
  {
    "id": "q01",
    "question": "What was the last altitude, in feet, that a controller told ENY5560 to climb or descend to?",
    "format": "a whole number of feet, for example 4000"
  },
  {
    "id": "q02",
    "question": "What was the last altitude, in feet, that a controller told N204GF to climb or descend to?",
    "format": "a whole number of feet, for example 4000"
  },
  {
    "id": "q03",
    "question": "What heading was DAL1509 last assigned by the tower?",
    "format": "three digits, for example 090"
  },
  {
    "id": "q04",
    "question": "Which runway was each of these arrivals last told to expect or cleared for?",
    "fields": {
      "ASA5128": "27L or 27R",
      "ENY3050": "27L or 27R",
      "N578VM": "27L or 27R"
    }
  },
  {
    "id": "q05",
    "question": "Which of these aircraft had still not begun, at the freeze, to follow an instruction given more than 20 seconds earlier?",
    "options": [
      "DAL1509",
      "ENY5560",
      "N204GF",
      "none of these"
    ]
  },
  {
    "id": "q06",
    "question": "Of the aircraft still in the air that hold a landing clearance at the freeze, which is closest to the runway? An aircraft that has landed does not count, and an aircraft told to go around no longer holds one. Answer \"none of these\" if no listed aircraft holds one.",
    "options": [
      "ASA5128",
      "ENY3050",
      "N578VM",
      "none of these"
    ]
  },
  {
    "id": "q07",
    "question": "Which of these aircraft is number two in the landing sequence for runway 27R at the freeze?",
    "options": [
      "ASA5128",
      "DAL1509",
      "N204GF",
      "N578VM"
    ]
  },
  {
    "id": "q08",
    "question": "Separation check. Every aircraft here is IFR and under terminal radar within 40 miles of the antenna. State the standard lateral and vertical radar separation minima that FAA Order JO 7110.65 sets for them (leave wake turbulence out of this question). Then, counting only airborne aircraft at or above 2,500 feet at the last track sample before the freeze (06:25), say how many aircraft that is and list every pair of them that is closer than the lateral minimum while also closer than the vertical minimum.",
    "fields": {
      "lateral_minimum_nm": "a number of nautical miles",
      "vertical_minimum_ft": "a number of feet",
      "aircraft_counted": "how many aircraft are airborne at or above 2,500 feet at that track sample",
      "pairs": "a list of pairs written like \"DAL1432/UAL882\", or an empty list if there are none"
    },
    "reference": "FAA Order JO 7110.65, paragraphs 5-5-4 and 4-5-1"
  },
  {
    "id": "q09",
    "question": "Audit. List every instance in this recording where a controller did not meet a requirement of FAA Order JO 7110.65. Count only failures by a controller, not by a pilot, and only what the handbook makes mandatory. If a controller handled something correctly, do not list it. List at most 12; an empty list is a valid answer.",
    "format": "a JSON list of findings, each an object with \"position\" (ground, tower or approach), \"aircraft\" (a list of the callsign codes involved), \"paragraph\" (the handbook paragraph, like 5-5-4) and \"reason\" (two to five sentences: what happened, with the time, and what led to it; which requirement was not met and why it applied here; and what the controller should have done)"
  },
  {
    "id": "q10",
    "question": "Look only at the runways. As things stand at the freeze, which of these arrivals, if any, cannot be allowed to land and has to be sent around?",
    "options": [
      "ASA5128",
      "ENY3050",
      "N578VM",
      "none of these"
    ]
  },
  {
    "id": "q11",
    "question": "Separation ahead. Assume each aircraft keeps flying to the heading and altitude it is now flying to, and that an aircraft that has not yet begun a change it was cleared for begins it at the freeze. Counting only airborne aircraft at or above 2,500 feet, which pair will be the first to come closer than the lateral minimum while also closer than the vertical minimum during the 120 seconds after the freeze? Use the standard radar minima and leave wake turbulence out. Do not count a pair that is already inside both minima at the freeze.",
    "fields": {
      "pair": "one pair written like \"DAL1432/UAL882\", or \"none\""
    },
    "reference": "FAA Order JO 7110.65, paragraphs 5-5-4 and 4-5-1"
  },
  {
    "id": "q12",
    "question": "What altitude, in feet, will ENY5560 be at 90 seconds after the freeze?",
    "options": [
      "4000",
      "5000",
      "6000",
      "7000"
    ]
  },
  {
    "id": "q13",
    "question": "What altitude, in feet, will DAL1509 be at 90 seconds after the freeze?",
    "options": [
      "5000",
      "6000",
      "7000",
      "8000"
    ]
  }
]
ATC_PROBES_EOF

# 5. Everything else in the working directory is removed.
find . -mindepth 1 -maxdepth 1 ! -name notes.md ! -name facility.md ! -name current ! -name setup.sh ! -name probes.json -exec rm -rf {} + 2>/dev/null
exit 0
