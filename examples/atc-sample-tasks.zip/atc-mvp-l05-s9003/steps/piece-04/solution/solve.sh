#!/bin/bash
echo 'minute 4 seen' >> notes.md
