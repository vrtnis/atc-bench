You are following live air traffic control around Metro airport: the tower, ground and approach frequencies and
the phone line between the three controllers.

The recording reaches you one minute at a time, and you cannot go back. This is minute 5 of 7,
covering 04:00 to 05:00.

Files in the working directory:

- `current/transcript.txt`: what was said on each channel in this minute
- `current/tracks.csv`: where the aircraft were in this minute
- `facility.md`: the airport, the file formats and the callsign table
- `notes.md`: the notes you have kept so far (empty at the start)

Your job in this step is to update `notes.md`.

After the last minute the recording is taken away and you will be asked questions about the traffic:
what is true at that moment, what it means, and what will happen next. You do not know the questions yet.
You will answer them from `notes.md` alone.

Rules:

- Each step starts with no memory of earlier steps. `notes.md` is the only thing you carry forward.
- `notes.md` is cut to its first 6,000 characters before each step. Keep it within that limit.
- Before the next minute everything else in the working directory is deleted or reset, including `facility.md`.
- Do not store information anywhere else: not in another file or folder, and not in a running program. Files
  written outside the working directory are recorded and reported with your score.
