#!/bin/bash
echo 'minute 5 seen' >> notes.md
